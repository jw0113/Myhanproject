package com.example.myhanproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class LoginActivity extends AppCompatActivity {
    EditText idText, passwordText;

    Button loginButton;
    Button joinButton;
    ImageButton exitButton;

    String getID, getPW;
    String ID, PW;

    Boolean id_text, password_text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        idText = (EditText) findViewById(R.id.idText);
        passwordText = (EditText) findViewById(R.id.passwordText);

        ID = idText.toString();
        PW = passwordText.toString();

        loginButton=(Button)findViewById(R.id.loginButton);
        joinButton=(Button)findViewById(R.id.joinButton);
        exitButton=(ImageButton)findViewById(R.id.exitButton);

        id_text = false;
        password_text = false;

        MainScreen();
        RegisterScreen();
        exit();

    }

    //로그인 버튼 눌렀을 때
    public void MainScreen(){
        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
//                String testurl = "http://54.180.42.62//dbdata.php";
//                URLConnector task = new URLConnector(testurl);
//
//                task.start();
//
//                try{
//                    //쓰레드가 끝나기 전까지 join에 머무르도록 한다.
//                    task.join();
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//
//                String result = task.getResult();
//                System.out.println(result);
//                //아이디와 비밀번호 자르기
//                //String[] result1 = result.split("/");
//                //String[] array = result1[1].split(",");   //id
//                //String[] array1 = result1[2].split(",");  //password
//
//                String target = "id";
//                String target1 = "비번";
//                int target_num = result.indexOf(target);
//                int target_num1 = result.indexOf(target1);
//
//                String result1 = result.substring(target_num+',');
//                String result2 = result.substring(target_num1+',');
//
//                String[] array = result1.split(",");
//                String[] array1 = result2.split(",");
//
//                //id와 password 존재하는지 비교하기
//                for(int i=0; i<array.length; i++){
//                    if(ID == array[i]){
//                        id_text = true;
//                        getID = array[i];
//                    }
//                    if(PW == array1[i]){
//                        password_text = true;
//                        getPW = array1[i];
//                    }
//                }
//
//                if(id_text == true && password_text == true){
//                    // 화면전환(Intent)
//                    Intent myIntent=new Intent(getApplicationContext(),Main2Activity.class);
//                    startActivity(myIntent);
//                }
//                else{
//                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
//                    builder.setMessage("아이디나 비밀번호가 잘못되었습니다.");
//                    builder.setTitle("로그인 알림창")
//                            .setCancelable(false)
//                            .setNegativeButton("close", new DialogInterface.OnClickListener() {
//                                @Override
//                                public void onClick(DialogInterface dialog, int i) {
//                                    dialog.cancel();
//                                }
//                            });
//                    AlertDialog alert = builder.create();
//                    alert.setTitle("로그인 알림창");
//                    alert.show();
//                }

                GetData task = new GetData();
                task.execute(idText.getText().toString(),passwordText.getText().toString());


            }
        });
    }

    //회원가입
    public void RegisterScreen(){
        joinButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // 화면전환(Intent)
                Intent myIntent=new Intent(getApplicationContext(),RegisterActivity.class);
                startActivity(myIntent);

            }
        });
    }
    public void exit(){
        exitButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                builder.setMessage("정말로 종료하시겠습니까?");
                builder.setTitle("종료 알림창")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("종료 알림창");
                alert.show();
            }
        });
    }

    private class GetData extends AsyncTask<String,String,String> {

        @Override
        protected String doInBackground(String... params) {

            String getid = params[0];
            String getpw = params[1];
            String testurl = "http://54.180.42.62//dbdata.php";
            String postParameters = "id = " + getid + "pw = " + getpw;
            String re = null;

            try{
                URL url = new URL(testurl);
                HttpURLConnection httpurlconnection = (HttpURLConnection)url.openConnection();

                httpurlconnection.setReadTimeout(5000);
                httpurlconnection.setConnectTimeout(5000);
                httpurlconnection.setRequestMethod("POST");
                httpurlconnection.setDoInput(true);
                httpurlconnection.connect();

                OutputStream outputStream = httpurlconnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpurlconnection.getResponseCode();
                //Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpurlconnection.getInputStream();
                }
                else{
                    inputStream = httpurlconnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }
                bufferedReader.close();
                re =  sb.toString();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return getResult(re);
        }

    }

    public String getResult(String jw){

    }
}