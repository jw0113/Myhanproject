package com.example.myhanproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class LoginActivity extends AppCompatActivity {
    Button loginButton;
    Button joinButton;
    ImageButton exitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginButton=(Button)findViewById(R.id.loginButton);
        joinButton=(Button)findViewById(R.id.joinButton);
        exitButton=(ImageButton)findViewById(R.id.exitButton);

        aaa();
        bbb();
        exit();

    }
    public void aaa(){
        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // 화면전환(Intent)
                Intent myIntent=new Intent(getApplicationContext(),Main2Activity.class);
                startActivity(myIntent);

            }
        });
    }
    public void bbb(){
        joinButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // 화면전환(Intent)
                Intent myIntent=new Intent(getApplicationContext(),RegisterActivity.class);
                startActivity(myIntent);

            }
        });
    }
    public void exit(){
        exitButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                builder.setMessage("정말로 종료하시겠습니까?");
                builder.setTitle("종료 알림창")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("종료 알림창");
                alert.show();
            }
        });
    }
}