package com.example.myhanproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class RegisterActivity extends AppCompatActivity {


    Button backButton;
    Button joinButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        
        joinButton=(Button)findViewById(R.id.joinButton);
        backButton=(Button)findViewById(R.id.backButton);

        join();
        back();

    }

    public void join(){
        joinButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // 화면전환(Intent)
                Intent myIntent=new Intent(getApplicationContext(),LoginActivity.class);

                startActivity(myIntent);

            }
        });
    }
    public void back(){
        backButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
                builder.setMessage("지금 내용을 지우고 뒤로가시겠습니까?");
                builder.setTitle("뒤로가기 알림창")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent myIntent= new Intent(getApplicationContext(),LoginActivity.class);
                                startActivity(myIntent);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("뒤로가기 알림창");
                alert.show();
            }
        });
    }

}


